To run the snake game program, simply load the game into a chrome browser webpage.
There are three buttons, start/stop, left, and right.
Right will make the snake turn right, and left will make it turn left.
If a wall is hit or the snake hits itself, the respective result will be given as a result and the game will end.
To reset the game, simply refresh the browser page.

To run the js experiments, simply load the file onto Node.js and execute it.